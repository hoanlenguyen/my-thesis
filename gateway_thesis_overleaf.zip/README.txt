Small Language Models for Smart Home Energy Management (thesis) for Overleaf

Upload this zip with New Project > Upload Project.
In Menu, set Main document to gateway_thesis.tex and Compiler to XeLaTeX.
Times New Roman and Arial are not on Overleaf; the preamble falls back to Liberation Serif/Sans or TeX Gyre.
gateway_thesis.tex is generated from gateway_body.tex by build_gateway_thesis.py in the repository.
